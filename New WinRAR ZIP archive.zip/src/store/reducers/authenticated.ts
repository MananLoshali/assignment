import { createSlice } from "@reduxjs/toolkit"
import type { PayloadAction } from "@reduxjs/toolkit";


interface IsAuthenticate {
    isAuthenticated: boolean;
}

const initialState: IsAuthenticate = {
    isAuthenticated: false
}

export const isUserSlice = createSlice({
    name: "authenticated",
    initialState,
    reducers: {
        authenticateUser: (state) => {
            state.isAuthenticated = true;
            return state
        },
        unAuthenticateUser: (state) => {
            state.isAuthenticated = false;
            return state
        },
    }
})

export const { authenticateUser, unAuthenticateUser } = isUserSlice.actions

export default isUserSlice.reducer