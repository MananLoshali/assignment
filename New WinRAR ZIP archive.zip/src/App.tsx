import { Route, Routes } from "react-router-dom";
import "./App.css";
import { useAppSelector } from "./store/store";
import Home from "./pages/home";
import NonGuartedRoute from "./layout/NonGuardedRoute";
import Login from "./pages/login";
import Register from "./pages/register";
import GuardedRoute from "./layout/GuardedRoute";

function App() {
  // const {name,email,age}  = useAppSelector(state=> state.users)

  return (
    <div>
      <Routes>
        <Route element={<NonGuartedRoute />}>
          <Route path="login" element={<Login />} />
          <Route path="register" element={<Register />} />
        </Route>
        <Route element={<GuardedRoute />}>
          <Route path="/" element={<Home />} />
        </Route>
      </Routes>
    </div>
  );
}

export default App;
