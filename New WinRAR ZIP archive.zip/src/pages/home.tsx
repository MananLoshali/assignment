import React from "react";
import { useForm } from "react-hook-form";
import { useAppDispatch } from "../store/store";
import { unAuthenticateUser } from "../store/reducers/authenticated";

const Home = () => {
  const deAuthUser = useAppDispatch();

  const form = useForm();
  const { handleSubmit } = form;

  const onClick = () => {
    deAuthUser(unAuthenticateUser());
  };

  return (
    <div>
      <button onClick={handleSubmit(onClick)}>Sign Out</button>
    </div>
  );
};

export default Home;
