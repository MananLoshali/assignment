import { Navigate, Outlet } from "react-router-dom";
import { useAppSelector } from "../store/store";

const NonGuartedRoute = () => {
  const isLoggedIn = useAppSelector(
    (state) => state.isAuthenticate.isAuthenticated
  );

  return isLoggedIn ? <Navigate to="/" /> : <Outlet />;
};

export default NonGuartedRoute;
