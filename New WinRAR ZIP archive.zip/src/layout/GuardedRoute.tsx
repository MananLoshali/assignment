import { Navigate, Outlet } from "react-router-dom";
import { useAppSelector } from "../store/store";

const GuardedRoute = () => {
  const isLoggedIn = useAppSelector(
    (state) => state.isAuthenticate.isAuthenticated
  );

  return isLoggedIn ? <Outlet /> : <Navigate to="/login" />;
};

export default GuardedRoute;
